var o="./assets/longLogo.66488773.png";export{o as _};
