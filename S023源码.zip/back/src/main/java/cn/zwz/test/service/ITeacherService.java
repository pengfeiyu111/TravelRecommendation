package cn.zwz.test.service;

import com.baomidou.mybatisplus.extension.service.IService;
import cn.zwz.test.entity.Teacher;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface ITeacherService extends IService<Teacher> {

}