package cn.zwz.data.dao.mapper;

import cn.zwz.data.entity.Permission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 郑为中
 * CSDN: Designer 小郑
 */
public interface PermissionMapper extends BaseMapper<Permission> {
}
